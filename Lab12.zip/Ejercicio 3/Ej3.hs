import Control.Monad (replicateM)

-- Definir la función para la transposición de la matriz usando lambda
transposeMatrix :: [[a]] -> [[a]]
transposeMatrix = foldr (zipWith (\x acc -> x : acc)) (repeat [])

-- Función para leer una fila de la matriz
leerFila :: Int -> IO [Int]
leerFila columnas = do
    putStrLn $ "Introduce " ++ show columnas ++ " elementos separados por espacios:"
    fmap (map read . words) getLine

-- Función para leer la matriz completa
leerMatriz :: Int -> Int -> IO [[Int]]
leerMatriz filas columnas = replicateM filas (leerFila columnas)

-- Función para imprimir la matriz de forma estructurada
imprimirMatriz :: Show a => [[a]] -> IO ()
imprimirMatriz matriz = do
    putStrLn "["
    mapM_ (\fila -> putStrLn ("  " ++ show fila ++ ",")) matriz
    putStrLn "]"

-- Función principal
main :: IO ()
main = do
    putStrLn "Introduce el número de filas:"
    filas <- readLn
    putStrLn "Introduce el número de columnas:"
    columnas <- readLn
    
    putStrLn "\nIntroduce los elementos de la matriz:"
    matriz <- leerMatriz filas columnas
    
    putStrLn "\nMatriz original:"
    imprimirMatriz matriz
    
    let transpuesta = transposeMatrix matriz
    putStrLn "\nMatriz transpuesta:"
    imprimirMatriz transpuesta
