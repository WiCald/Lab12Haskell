import Data.List (nub)
import System.IO (hFlush, stdout)

-- Función para eliminar los elementos indicados usando una función lambda
eliminarElementos :: [String] -> [String] -> [String]
eliminarElementos lista borrar = filter (\x -> not (x `elem` borrar)) lista

-- Función principal
main :: IO ()
main = do
    putStrLn "Introduce la lista inicial de elementos (separados por espacios):"
    putStr "> "
    hFlush stdout
    lista <- fmap words getLine
    
    putStrLn "Introduce la lista de elementos a borrar (separados por espacios):"
    putStr "> "
    hFlush stdout
    borrar <- fmap words getLine
    
    let resultado = eliminarElementos lista borrar
    putStrLn "\nLista resultante después de eliminar los elementos indicados:"
    print resultado
