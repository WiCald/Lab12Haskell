import Data.List (sortBy)
import System.IO (hFlush, stdout)

type Car = [(String, String)]

-- Función para ordenar la lista de diccionarios según una clave dada
sortCars :: String -> [Car] -> [Car]
sortCars key cars
    | key == "marca" = sortBy (\a b -> compare (lookup key a) (lookup key b)) cars
    | key == "year"  = sortBy (\a b -> compare (read (getValue key a) :: Int) (read (getValue key b) :: Int)) cars
    | otherwise      = cars
  where
    getValue :: String -> Car -> String
    getValue k car = case lookup k car of
                        Just value -> value
                        Nothing    -> ""

-- Función principal para interactuar con el usuario
main :: IO ()
main = do
    let cars = [ [("marca", "Toyota"), ("modelo", "Corolla"), ("year", "2020")],
                 [("marca", "Ford"), ("modelo", "Mustang"), ("year", "2018")],
                 [("marca", "Honda"), ("modelo", "Civic"), ("year", "2019")],
                 [("marca", "Chevrolet"), ("modelo", "Camaro"), ("year", "2021")] ]

    putStrLn "Lista original de autos:"
    print cars
    
    putStrLn "\n¿Cómo deseas ordenar la lista? (marca/year):"
    putStr "> "
    hFlush stdout
    criterio <- getLine

    let sortedCars = sortCars criterio cars
    putStrLn "\nLista ordenada:"
    print sortedCars
