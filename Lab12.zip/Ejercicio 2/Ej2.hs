main :: IO ()
main = do
    -- Lista de enteros
    let lista = [3, 5, 7, 9, 11]
    print lista
    
    -- Pedir al usuario el valor de n
    putStrLn "Introduce la potencia (n):"
    n <- readLn :: IO Int
    
    -- Calcular la potencia n-ésima de cada elemento en la lista
    let resultado = map (\x -> x ^ n) lista
    
    -- Mostrar resultado
    putStrLn "Lista original:"
    print lista
    putStrLn $ "\nLista con cada elemento elevado a la potencia " ++ show n ++ ":"
    print resultado
